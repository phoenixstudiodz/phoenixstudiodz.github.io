# Basis Set Meta Data Parsing Code

Repository to track basis set meta data parsing code

## HTML

Realtime JSON parsing from basis set exchange

Initial Contractor (Upwork): Aleksandar Radmanovac

Subsequent Contractor (Upwork): Amel Daho

## XLSX

Generated manually by offshore upwork resource.

Filename is bse_listing.xlsx

Contractor: MD Mostafizur Rahman (via Upwork)

## Source:

https://www.basissetexchange.org