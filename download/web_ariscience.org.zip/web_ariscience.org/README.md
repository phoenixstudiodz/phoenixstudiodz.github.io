# Goals

Keep the files here as simple as possible

## Resources

### BSE Filter

Initial Contractor (Upwork): Aleksandar Radmanovac

Subsequent Contractor (Upwork): Amel Daho

### 3D File Downloader

XXX

## Common Header Information

### Google Analytics To Use

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-144973238-2"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-144973238-2');
    </script>
    
### Style to Use (NO CUSTOM CSS)

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

        <!--favicon-->
        <link rel="icon" type="image/png" href="images/ari_logo_small.png">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 

## Communications/Protocols

### FTP Push

Landing of the following FTP user is in the public_html page.

    Site: ariscience.org
    Username: website@ariscience.org
    Password: foo+"shat at noi"+AB
    

### HTTP to HTTPS

We put the following in .htaccess folder as per https://my.bluehost.com/hosting/help/force-ssl-all-pages

    RewriteEngine On 
    RewriteCond %{HTTPS} off 
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]    

## Future Resources to Consider Incorporating

1. https://github.com/biochem-fan/GLmol, License: dual license of MIT or LGPL3
2. https://github.com/eligrey/FileSaver.js, License: MIT license
3. https://github.com/eligrey/Blob.js, License: MIT license 
4. http://jquery.com/, License: MIT license   
5. https://github.com/jeresig/jquery.hotkeys, License: MIT license
6. https://github.com/diniska/chemistry/blob/master/PeriodicalTable/periodicTable.json, XXX WHAT LICENSE XXX
7. https://github.com/mrdoob/three.js, License: MIT license