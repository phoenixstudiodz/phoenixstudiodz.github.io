=== Easy Voice Mail ===
Contributors: Phoenix Studio
Donate link: https://phoenix-dz/easy-voice-mail/
Tags: accessiblity, voice, contact
Requires at least: 5.2
Tested up to: 5.2
Stable tag: trunk
Requires PHP: 5.5
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Provide a simpler, more efficient way for you client to contact you and express their needs.

== Description ==

Easy Voice mail Provide a simpler, more efficient way for you client to contact you and express their needs.
This plugin provide an easy way to enable your client to contact you by voice mail, all they need is to hit the record button and save the message once they are done.
* The plugin provide an easy user interface to review and manage the messages.
* The plugin provide options to limit the message duration.
* The plugin will enable (request using) microphone only during recording.
How to install:
1. Download the plugin, click activate
2. put [easy_voice_mail] where you to display the plugin for your clients.
To access the messages, login as admin, go to Tools -> Easy Voice Mail 
Due to security limitations in most browser the plugin will work only on https connection


== Installation ==

1. Download the plugin, click activate
2. put [easy_voice_mail] where you display it for your clients.
To access the messages, login as admin, go to Tools -> Easy Voice Mail

== Frequently Asked Questions ==

= Why the plugin work only on https =

This is because the browser prohibit the usage of microphone/camera for non https connection


== Screenshots ==


== Changelog ==


== Upgrade Notice ==

